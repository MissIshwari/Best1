<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>Ummat</title>
        <link href="{{mix('css/app.css')}}" rel="stylesheet" type="text/css">
    </head>
    <body>
        <header id="header"></header>
        <div id="slider"></div>
        <div id="home" class="container"></div>
        <footer id="footer" class="py-5 bg-dark"></footer>
        <script src="{{mix('js/app.js')}}" ></script>
    </body>
</html>